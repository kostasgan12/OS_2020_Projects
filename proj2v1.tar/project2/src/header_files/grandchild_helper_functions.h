#include <stdio.h> 
#include <stdlib.h>
#include <math.h>


bool isPrime_1(int n);
bool isPrime_2(int n);