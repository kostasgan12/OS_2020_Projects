#ifndef GRANDCHILD_MAIN_H
#define GRANDCHILD_MAIN_H

#include <cstdlib>
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <ctime>
#include <cmath>
#include <new>

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>

#include "../header_files/grandchild_helper_functions.h"

using namespace std;

extern int lowestValue;
extern int upperValue;

#endif